//
//  LocationStates.swift
//  Location Services
//
//  Created by Eric Internicola on 12/31/18.
//  Copyright © 2018 Eric Internicola. All rights reserved.
//

import CoreLocation


/// The current Location Services Authorization state
enum LocationAuthorizationState: String {
    case unknownAuthorization
    case deniedAuthorization
    case approvedAuthorization

    /// Distills the current location authorization status down to three
    /// simple states:
    static var current: LocationAuthorizationState {
        switch CLLocationManager.authorizationStatus() {
        case .notDetermined:
            return .unknownAuthorization

        case .denied, .restricted:
            return .deniedAuthorization

        case .authorizedAlways, .authorizedWhenInUse:
            return .approvedAuthorization
        }
    }
}
