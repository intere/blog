//
//  ViewController.swift
//  Location Services
//
//  Created by Eric Internicola on 12/31/18.
//  Copyright © 2018 Eric Internicola. All rights reserved.
//

import CoreLocation
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var authLabel: UILabel!
    @IBOutlet weak var trackingLabel: UILabel!
    @IBOutlet weak var actionButton: UIButton!

    /// The location manager (where we get our location from)
    let manager = CLLocationManager()

    /// keeps track of whether or not we're tracking, currently.
    private var tracking = false

    override func viewDidLoad() {
        super.viewDidLoad()
        manager.delegate = self
        updateUIState()
    }

}

// MARK: - User Actions

private extension ViewController {

    @IBAction
    /// Handles the button tap, but it will take a different action based on the
    /// current authorization and tracking states.
    ///
    /// - Parameter source: the source of the event.
    func tappedButton(_ source: Any) {
        switch LocationAuthorizationState.current {
        case .unknownAuthorization:
            manager.requestWhenInUseAuthorization()

        case .approvedAuthorization:
            if tracking {
                stopTracking()
            } else {
                startTracking()
            }
            updateUIState()

        case .deniedAuthorization:
            openSettings()
        }
    }

}

// MARK: - Location Delegate

extension ViewController: CLLocationManagerDelegate {

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        updateUIState()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let lastPoint = locations.last else {
            return
        }
        trackingLabel.text = "\(lastPoint)"
    }

}

// MARK: - Implementation

private extension ViewController {

    /// Are we currently tracking?
    var isTracking: Bool {
        return tracking
    }

    /// Begin tracking
    func startTracking() {
        tracking = true
        configureUpdates()
        manager.startUpdatingLocation()
    }

    /// Finish tracking
    func stopTracking() {
        tracking = false
        manager.stopUpdatingLocation()
    }

    /// Configure the Location Manager for our trackign requirements
    func configureUpdates() {
        manager.activityType = .fitness
        manager.desiredAccuracy = kCLLocationAccuracyBest
    }

    /// Opens the system settings for our app
    func openSettings() {
        guard let systemSettingsUrl = URL(string: UIApplication.openSettingsURLString) else {
            return
        }
        UIApplication.shared.openURL(systemSettingsUrl)
    }

    /// Updates the title of the button, based on the authorization state
    /// and tracking state.
    func updateUIState() {
        switch LocationAuthorizationState.current {
        case .approvedAuthorization:
            authLabel.text = "Access approved by user"
            if tracking {
                actionButton.setTitle("Stop Tracking", for: .normal)
            } else {
                trackingLabel.text = "Not Tracking"
                actionButton.setTitle("Start Tracking", for: .normal)
            }

        case .unknownAuthorization:
            authLabel.text = "Access not yet requested"
            actionButton.setTitle("Request Access", for: .normal)

        case .deniedAuthorization:
            authLabel.text = "Access denied by user"
            actionButton.setTitle("Open Settings", for: .normal)
        }
    }
}




